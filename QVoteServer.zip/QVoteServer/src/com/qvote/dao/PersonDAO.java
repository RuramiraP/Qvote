/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.qvote.dao;

import com.qvote.model.Person;
import java.sql.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author hnjej
 */
public class PersonDAO {

    public boolean savePerson(Person person) {
        Session session = SessionFactoryUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(person);
        tx.commit();
        session.close();
        return true;
    }

    public boolean createPerson(Person person) {
        String url = "jdbc:postgresql://localhost:5433/qvote_db";
        String sql = "INSERT INTO person VALUES(?,?,?,?,?)";
        Connection con = null;
        boolean result = false;
        try {
            con = DriverManager.getConnection(url, "postgres", "postgres");

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, person.getIdNo());
            ps.setString(2, person.getFirstName());
            ps.setString(3, person.getLastName());
            ps.setDate(4, Date.valueOf(person.getDateOfBirth()));
            ps.setString(5, person.getPhysicalAddress());

            ps.executeUpdate();
            result = true;
        } catch (SQLException ex) {
            Logger.getLogger(PersonDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(PersonDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return result;
    }

    public boolean createPerson(List<Person> persons) {
        int batchSize = 500;
        int counter = 0;
        String url = "jdbc:postgresql://localhost:5433/qvote_db";
        String sql = "INSERT INTO person VALUES(?,?,?,?,?)";
        Connection con = null;
        boolean result = false;
        try {
            con = DriverManager.getConnection(url, "postgres", "postgres");
            con.setAutoCommit(false);
            PreparedStatement ps = con.prepareStatement(sql);
            for (Person person : persons) {
                ps.setString(1, person.getIdNo());
                ps.setString(2, person.getFirstName());
                ps.setString(3, person.getLastName());
                ps.setDate(4, Date.valueOf(person.getDateOfBirth()));
                ps.setString(5, person.getPhysicalAddress());
                ps.addBatch();
                counter++;
                if (counter == batchSize) {
                    ps.executeBatch();
                    counter = 0;
                }
            }
            ps.executeBatch();
            con.commit();
            result = true;
        } catch (SQLException ex) {
            try {
                con.rollback();
            } catch (SQLException ex1) {
                Logger.getLogger(PersonDAO.class.getName()).log(Level.SEVERE, null, ex1);
            }
            Logger.getLogger(PersonDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.setAutoCommit(true);
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(PersonDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return result;
    }

    public void update(Person person) {
        Session session = SessionFactoryUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.update(person);
        tx.commit();
        session.close();
    }

}
