/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qvote.dao;

import com.qvote.model.Position;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author hnjej
 */
public class PositionDAO {
    public void savePosition(Position position){
        Session session=SessionFactoryUtil.getSessionFactory().openSession();
        Transaction tx=session.beginTransaction();
        session.save(position);
        tx.commit();
        session.close();
    }
}
