/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qvote.service;

import com.qvote.dao.PositionDAO;
import com.qvote.model.Position;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author hnjej
 */
public class PositionService extends UnicastRemoteObject implements PositionServiceInterface{

    public PositionService() throws RemoteException{
        super();
    }
    @Override
    public void savePosition(Position position) throws RemoteException {
        PositionDAO dao=new PositionDAO();
        dao.savePosition(position);
    }
    
}
