/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qvote.service;

import com.qvote.dao.PersonDAO;
import com.qvote.model.Person;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 *
 * @author hnjej
 */
public class PersonService extends UnicastRemoteObject implements PersonServiceInterface {

    public PersonService() throws RemoteException {
        super();
    }
    
    @Override
    public void savePerson(Person person) throws RemoteException {
        PersonDAO dao = new PersonDAO();
        dao.savePerson(person);
    }

    @Override
    public void update(Person person) throws RemoteException {
        PersonDAO dao = new PersonDAO();
        dao.update(person);
    }

}
