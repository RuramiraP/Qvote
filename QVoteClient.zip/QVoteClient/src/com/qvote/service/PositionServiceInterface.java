/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qvote.service;

import com.qvote.model.Position;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 *
 * @author hnjej
 */
public interface PositionServiceInterface extends Remote{
    public void savePosition(Position position) throws RemoteException;
}
