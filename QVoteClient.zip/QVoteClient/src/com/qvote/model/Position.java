package com.qvote.model;
// Generated Nov 7, 2022 7:20:19 PM by Hibernate Tools 4.3.1

public class Position  implements java.io.Serializable {
     private String code;
     private String positionName;
     private short mandateMonths;
     private String criteria;

    public Position() {
    }

    public Position(String code, String positionName, short mandateMonths, String criteria) {
       this.code = code;
       this.positionName = positionName;
       this.mandateMonths = mandateMonths;
       this.criteria = criteria;
    }
   
    public String getCode() {
        return this.code;
    }
    
    public void setCode(String code) {
        this.code = code;
    }
    public String getPositionName() {
        return this.positionName;
    }
    
    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }
    public short getMandateMonths() {
        return this.mandateMonths;
    }
    
    public void setMandateMonths(short mandateMonths) {
        this.mandateMonths = mandateMonths;
    }
    public String getCriteria() {
        return this.criteria;
    }
    
    public void setCriteria(String criteria) {
        this.criteria = criteria;
    }




}


